<html>

    <head>
    </head>

    <body>

        <form method="POST">
            Login: <input type="text" name="login"><br>
            Hasło: <input type="password" name="haslo"><br>
            Imię: <input type="text" name="imie"><br>
            Nazwisko: <input type="text" name="nazwisko"><br>
            Szkoła: <input type="text" name="szkola"><br>
            Adres: <input type="text" name="adres"><br>
            Telefon: <input type="number" name="telefon"><br>
            <input name="register" type="submit" value="Zarejestruj Się!">
        </form>
    
        <?php
            $user= 'root';
            $pass= '';
            $host = 'localhost';
            $base = 'konkurs';
            $conn= mysqli_connect($host,$user,$pass, $base);
            mysqli_select_db($conn,$base);


            if(isset($_POST['register'])) {
                $login = $_POST['login'];
                $haslo = $_POST['haslo'];
                $imie = $_POST['imie'];
                $nazwisko = $_POST['nazwisko'];
                $szkola = $_POST['szkola'];
                $adres = $_POST['adres'];
                $telefon = $_POST['telefon'];

                $query = "INSERT INTO uzytkownicy(login, haslo, imie, nazwisko, szkola, adres, telefon) values('$login', '$haslo', '$imie', '$nazwisko', '$szkola', '$adres', '$telefon')";
                $run =mysqli_query($conn,$query) or die(mysqli_error());
            }
        ?>
    </body>

</html>