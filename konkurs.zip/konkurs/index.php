<html>

    <head>
    </head>

    <body>
        <div class="content">
            <center><h1>Konkurs!</h1></center>
            <a href="logowanie_paw.php">Logowanie</a>
            <a href="zakladanie_paw.php">Zarejestruj Się!</a>
        </div>
    </body>

</html>