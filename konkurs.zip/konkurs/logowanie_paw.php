<html>

    <head>
    </head>

    <body>
        <form method="POST">
            Login: <input type="text" name="login"><br>
            Hasło: <input type="password" name="haslo"><br>
            <input name="login" type="submit" value="Zaloguj Się!">
        </form>

        <?php
            $user= 'root';
            $pass= '';
            $host = 'localhost';
            $base = 'konkurs';
            $conn= mysqli_connect($host,$user,$pass, $base);
            mysqli_select_db($conn,$base);


            if(isset($_POST['login'])) {
                $login = $_POST['login'];
                $haslo = $_POST['haslo'];

                $query = "SELECT * FROM uzytkownicy";
                
                $run =mysqli_query($conn,$query) or die(mysqli_error());
            }
        ?>
    </body>

</html>